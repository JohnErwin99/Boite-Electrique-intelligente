package HiérarchieAppareil;

public class AppareilAvecInterrupteur extends AppareilAbstrait{

	public AppareilAvecInterrupteur(String categorie, int tension, double amperage, int etat, String emplacement) {
		super(categorie, tension, amperage, etat, emplacement);
		// TODO Auto-generated constructor stub
	}

	@Override
    public boolean aUnVariateur() {
        return false;
    }

    @Override
    public double getPuissance() {
    	if(etat == 1)
    		return tension * amperage;
    	return 0;
    }

    @Override
    public boolean estAllume() {
    	if(etat == 1)
    		return true;
    	return false;
    }
}
