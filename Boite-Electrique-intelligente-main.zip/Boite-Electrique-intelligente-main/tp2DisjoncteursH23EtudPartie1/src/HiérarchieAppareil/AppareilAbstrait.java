package HiérarchieAppareil;

public class AppareilAbstrait implements InterfaceAppareil{
	protected String categorie;
    protected int tension;
    protected double amperage;
    protected int etat;
    protected String emplacement;
    
    public AppareilAbstrait(String categorie, int tension, double amperage, int etat, String emplacement) {
        this.categorie = categorie;
        this.tension = tension;
        this.amperage = amperage;
        this.etat = etat;
        this.emplacement = emplacement;
    }

    public String getCategorie() {
        return categorie;
    }

    public int getTension() {
        return tension;
    }

    public double getAmperage() {
        return amperage;
    }

    public int getEtat() {
        return etat;
    }

    public String getEmplacement() {
        return emplacement;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }
	@Override
	public boolean aUnVariateur() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double getPuissance() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean estAllume() {
		// TODO Auto-generated method stub
		return false;
	}

}
