package HiérarchieAppareil;

public interface InterfaceAppareil {
	boolean aUnVariateur();
    double getPuissance();
    boolean estAllume();
}
