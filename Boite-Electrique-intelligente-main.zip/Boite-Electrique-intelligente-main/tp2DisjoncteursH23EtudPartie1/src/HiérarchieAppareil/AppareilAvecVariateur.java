package HiérarchieAppareil;

public class AppareilAvecVariateur extends AppareilAbstrait{
	private double positionVariateur;

    public AppareilAvecVariateur(String categorie, int tension, double amperage, int etat, String emplacement, double positionVariateur) {
        super(categorie, tension, amperage, etat, emplacement);
        this.positionVariateur = positionVariateur;
    }

    public AppareilAvecVariateur(String categorie, double amperage, int tension, String emplacement, double positionVariateur) {
    	super(categorie, tension, amperage, tension, emplacement);
        this.positionVariateur = positionVariateur;	}

	@Override
    public boolean aUnVariateur() {
        return true;
    }

    @Override
    public double getPuissance() {
    	if(etat == 1)
    		return tension * amperage * positionVariateur;
    	return 0;
    }

    @Override
    public boolean estAllume() {
    	if(etat == 1)
    		return true;
    	return false;
    }

    public double getPositionVariateur() {
        return positionVariateur;
    }

    public void setPositionVariateur(double positionVariateur) {
        this.positionVariateur = positionVariateur;
    }
}
