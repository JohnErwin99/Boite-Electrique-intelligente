package graphiqueGui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import HiérarchieAppareil.AppareilAbstrait;
import disjoncteurs.Boite;
import disjoncteurs.Disjoncteur;
import utile.UtilitaireGestionMenu;;

class DisjoncteurGui extends JPanel implements ActionListener{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel DisjoncteurGui;
	private JPanel PanneauInfoBoite;
	private JPanel PanneauDisjoncteurs;
	Disjoncteur disjoncteur;
    private int ligne;
    private int colonne;

    public DisjoncteurGui(JPanel PanneauInfoBoite, JPanel PanneauDisjoncteurs,  Disjoncteur disjoncteur, int ligne, int colonne) {
    	this.PanneauDisjoncteurs = PanneauDisjoncteurs;
    	this.PanneauInfoBoite = PanneauInfoBoite;
    	this.disjoncteur = disjoncteur;
    	this.DisjoncteurGui = this;
    	this.ligne = ligne;
        this.colonne = colonne;

        if (disjoncteur == null) {
            JButton btnVide = new JButton();
            btnVide.setPreferredSize(new Dimension(200, 30));
            btnVide.setEnabled(true);
            btnVide.addActionListener(this);
            add(btnVide);

            JButton btnGris = new JButton();
            btnGris.setBackground(Color.GRAY);
            btnGris.setPreferredSize(new Dimension(200, 30));
            btnGris.setEnabled(false);
            add(btnGris);
        } else {
            // Bouton avec les données du disjoncteur
            JButton btnDonnees = new JButton(disjoncteur.getAmpere() + "/" + 
            disjoncteur.getTension() + disjoncteur.getPuissanceEnWatt());
            btnDonnees.setPreferredSize(new Dimension(200, 30));
            btnDonnees.addActionListener(this);
            btnDonnees.setEnabled(true);
            add(btnDonnees);

            // Interrupteur dans le bon état
            String etatAllume = String.valueOf(disjoncteur.getEtat());
            InterrupteurGui interrupteurGui = new InterrupteurGui(etatAllume);
            add(interrupteurGui);
        }
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		if(disjoncteur == null) {
			UtilitaireGestionMenu.ajouterDisjoncteur(new Boite(CadreBoiteDisjonction.MAX_AMPERE_DEFAUT));
			
			mettreAJourPanneaux();
		}
		else {
			FenetreSaisieAppareil appareil = new FenetreSaisieAppareil();
			if(FenetreSaisieAppareil.getAppareil().getTension() == disjoncteur.getTension()) {
				disjoncteur.ajouterAppareil(FenetreSaisieAppareil.getAppareil());
				mettreAJourPanneaux();
			}
			else {
                JOptionPane.showMessageDialog(DisjoncteurGui, "Les tensions doivent être égales.");
			}
		}
	}
	
	private void mettreAJourPanneaux() {
		PanneauInfoBoite.removeAll();
		PanneauDisjoncteurs.removeAll();
        
        // Ajoutez des nouveaux boutons et éléments à panneauInfoBoite et panneauDisjoncteur ici

		PanneauInfoBoite.validate();
		PanneauInfoBoite.repaint();
        PanneauDisjoncteurs.validate();
        PanneauDisjoncteurs.repaint();
    }
}
