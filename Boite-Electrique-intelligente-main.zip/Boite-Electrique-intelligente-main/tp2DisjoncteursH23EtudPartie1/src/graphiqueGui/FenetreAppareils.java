package graphiqueGui;

import javax.swing.*;

import HiérarchieAppareil.AppareilAbstrait;
import HiérarchieAppareil.AppareilAvecInterrupteur;
import disjoncteurs.Disjoncteur;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class FenetreAppareils extends JDialog {
	
    private Disjoncteur disjoncteur;
    private JPanel panneauAppareils;

    public FenetreAppareils() {
        setTitle("Appareils");
        setSize(400, 300);
        setModal(true);
        setLocationRelativeTo(null);

        panneauAppareils = new JPanel();
        panneauAppareils.setLayout(new BoxLayout(panneauAppareils, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(panneauAppareils);
        add(scrollPane);

        afficherAppareils();

        setVisible(true);
    }

    private void afficherAppareils() {
        AppareilAbstrait[] appareils = disjoncteur.getTabAppareils();
        for (AppareilAbstrait appareil : appareils) {
            JPanel panneauAppareil = new JPanel();
            panneauAppareil.setLayout(new FlowLayout(FlowLayout.LEFT));

            String typeAppareil = appareil instanceof AppareilAvecInterrupteur ? "Interrupteur" : "Variateur";
            JLabel labelAppareil = new JLabel(typeAppareil + ": " + appareil.toString());
            panneauAppareil.add(labelAppareil);

            JButton boutonSupprimer = new JButton("x");
            boutonSupprimer.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    disjoncteur.retirerAppareil(0);
                    panneauAppareils.remove(panneauAppareil);
                    panneauAppareils.revalidate();
                    panneauAppareils.repaint();
                }
            });
            panneauAppareil.add(boutonSupprimer);

            panneauAppareils.add(panneauAppareil);
        }
    }
}
