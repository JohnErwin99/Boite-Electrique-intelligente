/**
 * 
 */
package graphiqueGui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import disjoncteurs.Boite;
import utile.UtilitaireGestionMenu;

/**
 * @author jerwin
 *
 */
public class InterrupteurGui extends JPanel implements ActionListener{
	
	private String etat;
	public InterrupteurGui(String etat) {
		this.etat = etat;
		
		if (etat == "ALLUME") {
            JButton btnNoir = new JButton();
            btnNoir.setBackground(Color.BLACK);
            btnNoir.setPreferredSize(new Dimension(100, 30)); // La moitié de la taille du bouton pour un disjoncteur.
            btnNoir.setEnabled(true);
            btnNoir.addActionListener(null);
            add(btnNoir);

            JButton btnBlanc = new JButton();
            btnBlanc.setBackground(Color.WHITE);
            btnBlanc.setPreferredSize(new Dimension(100, 30)); 
            btnBlanc.setEnabled(true);
            btnBlanc.addActionListener(this);
            add(btnBlanc);
        } else {
            JButton btnRouge = new JButton();
            btnRouge.setBackground(Color.RED);
            btnRouge.setPreferredSize(new Dimension(100, 30)); 
            btnRouge.setEnabled(true);
            btnRouge.addActionListener(this);
            add(btnRouge);

            JButton btnNoir = new JButton();
            btnNoir.setBackground(Color.BLACK);
            btnNoir.setPreferredSize(new Dimension(100, 30)); 
            btnNoir.setEnabled(true);
            btnNoir.addActionListener(this);
            add(btnNoir);
        }
	}
	
	public void actionPerformed(ActionEvent e) {
		if(etat == "ALLUME") {
			FenetreAppareils fenetreSommaire = new FenetreAppareils();
			
			
			mettreAJourPanneaux();
		}
		else {
                JOptionPane.showMessageDialog(this, "Null");
		}
	}
	
	private void mettreAJourPanneaux() {
		this.removeAll();
		//PanneauDisjoncteurs.removeAll();
        
        // Ajoutez des nouveaux boutons et éléments à panneauInfoBoite et panneauDisjoncteur ici

		this.validate();
		this.repaint();
        //PanneauDisjoncteurs.validate();
        //PanneauDisjoncteurs.repaint();
    }
}
